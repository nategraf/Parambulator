

(function(ns){
	
	window.GreenSockAMDPath = "vendor/greensock";
			
})(window.portfolio = window.portfolio || {});