({
    appDir: "./",
    baseUrl: "./",
    dir: "../js-build",
    modules: [
        {
            name: "app"
        }
    ],
	mainConfigFile: 'app.js',
    
})